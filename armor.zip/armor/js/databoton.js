const databoton = (prefix) => {
return `
Olá, este comando eu criei com ideias de outros comandos que vi partes necessárias para criar esse, e através de uma sugestão de uma pessoa.

...vamos lá, irei explicar como funciona. 

Existe esses 2 comandos que faz parte da função. 

${prefix}tempogp 

E 

${prefix}ativartempo 


Com o comando ${prefix}tempogp você determina qual data você deseja que o bot pare de funcionar no grupo que você utilizou ou vai utilizar o comando. 

depois logo em seguida utilize o comando 

${prefix}ativartempo 

Exemplo :

${prefix}tempogp 20/12

Esse comando foi criado para pessoas que costuma alugar o bot para grupo, ele vai pagar nessa data que você determinou, depois só renovar kkk

Boa sorte. 

Assinado, criador do comando : Aleatory Conteúdos == Josival. 
`
}

exports.databoton = databoton