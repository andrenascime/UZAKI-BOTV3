const infobemvindo = (prefix) => {
return `

Olá, este comando é para informar, como você deve ativar o bem vindo, e lembrando, esse bemvindo, contém uma legenda diferente, a cada grupo que for colocado, o bemvindo2 tem essa função também. 


(ATENÇÃO - BEMVINDO2 NÃO TEM FOTO, SÓ LEGENDA. 
E É IGUAL O PROCEDIMENTO, SÓ MUDAR DE ${prefix}bemvindo pra ${prefix}bemvindo2 e os outros a mesma coisa, legendabv2 legendasaiu2, é isso... )

Pará ativar o comando, é nescessario ativar, com:

${prefix}bemvindo 1 

Pará Desativar :

${prefix}bemvindo 0


Pronto. 

Pará criar a legenda você deve digitar este comando :

${prefix}legendabv e colocar a legenda que você quer que o bot envie, após alguém entrar no grupo, e tem essas coisas. 

#nomedogp#

#numerobot#

#numerodele#

#prefixo#

#descrição#




Se eu fazer uma legenda assim, por exemplo: 

${prefix}legendabv Olá seja bem vindo(a) ao grupo : #numerodele# 

Grupo: #nomedogp#

Prefixo do bot : #prefixo#

Leia as regras : 

#descrição#


E também tem esse:

${prefix}legendasaiu e digita oq quer, por exemplo, Adeus.

mas não recomendo colocar legenda, é bom que só vem o bemvindo kkkk, vai aparecer que a legenda N foi definida kkkk


Pronto, se eu envio assim, no grupo que estou, toda vez que alguém entrar, sera enviado isso, o que você definiu ali 

#numerodele# = vai aparecer o numero dele, com essa definição. 

#nomedogp# = vai aparecer o nome do grupo com essa definição. 

#prefixo# = vai aparecer qual o símbolo que você está utilizando no bot, pra fazer ele funcionar.

#descrição# = vai aparecer a descrição do grupo todo. 



Pra trocar o fundo da imagem do bemvindo, é só mandar uma foto no WhatsApp, retangular e marcar ela com o comando :

${prefix}fundobemvindo 

Ou se quer trocar a do saiu 

${prefix}fundosaiu 

Só marcar uma foto e pronto, com o comando. 

Vale pra a foto do menu também. 

${prefix}fotomenu só marcar uma foto, que já é trocado.




É isso galera, buenas suerte ae.





----------------------------
CRÉDITOS DO BEM VINDO : 

Brizas-Bot = Ian.


Assinado: Aleatory Bot. 

-----------------------------
`
}

exports.infobemvindo = infobemvindo